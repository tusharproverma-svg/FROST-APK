package com.tushar.frost;

import android.app.Application;
import android.content.SharedPreferences;

/** ऐप के सबसे पहले पल से क्रैश पकड़ता है और अगली बार खुलने पर MainActivity दिखाती है। */
public class FrostApp extends Application {
    @Override
    public void onCreate() {
        super.onCreate();
        final SharedPreferences sp = getSharedPreferences("frost_crash", MODE_PRIVATE);
        final Thread.UncaughtExceptionHandler prev = Thread.getDefaultUncaughtExceptionHandler();
        Thread.setDefaultUncaughtExceptionHandler(new Thread.UncaughtExceptionHandler() {
            @Override
            public void uncaughtException(Thread t, Throwable e) {
                try {
                    java.io.StringWriter w = new java.io.StringWriter();
                    e.printStackTrace(new java.io.PrintWriter(w));
                    String tr = w.toString();
                    sp.edit().putString("trace", tr.length() > 2200 ? tr.substring(0, 2200) : tr).commit();
                } catch (Throwable x) {
                    // ठीक है
                }
                if (prev != null) {
                    prev.uncaughtException(t, e);
                }
            }
        });
    }
}
