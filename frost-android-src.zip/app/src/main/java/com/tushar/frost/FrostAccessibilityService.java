package com.tushar.frost;

import android.accessibilityservice.AccessibilityService;
import android.content.Intent;
import android.os.Handler;
import android.os.Looper;
import android.view.accessibility.AccessibilityEvent;
import android.view.accessibility.AccessibilityNodeInfo;

import java.util.List;

/**
 * सिर्फ़ तीन काम: (1) फ़ोन लॉक / होम / पीछे, (2) व्हाट्सएप में Send दबाना जब FROST ने संदेश तैयार किया हो।
 * यह सिर्फ़ व्हाट्सएप की स्क्रीन देखता है (accessibility_service_config.xml में packageNames)।
 */
public class FrostAccessibilityService extends AccessibilityService {

    static FrostAccessibilityService inst;
    static volatile long armUntil = 0;
    private final Handler h = new Handler(Looper.getMainLooper());

    /** अगले 25 सेकंड में व्हाट्सएप खुले तो Send दबा दो। */
    static void armSend() {
        armUntil = System.currentTimeMillis() + 25000;
    }

    static boolean globalAction(int action) {
        FrostAccessibilityService s = inst;
        return s != null && s.performGlobalAction(action);
    }

    @Override
    protected void onServiceConnected() {
        super.onServiceConnected();
        inst = this;
    }

    @Override
    public void onAccessibilityEvent(AccessibilityEvent event) {
        if (System.currentTimeMillis() > armUntil) {
            return;
        }
        AccessibilityNodeInfo root = getRootInActiveWindow();
        if (root == null) {
            return;
        }
        CharSequence pkg = root.getPackageName();
        if (pkg == null || !pkg.toString().startsWith("com.whatsapp")) {
            return;
        }
        AccessibilityNodeInfo send = null;
        List<AccessibilityNodeInfo> l = root.findAccessibilityNodeInfosByViewId("com.whatsapp:id/send");
        if (l != null && !l.isEmpty()) {
            send = l.get(0);
        }
        if (send == null) {
            String[] names = new String[]{"Send", "भेजें", "भेजो"};
            for (String n : names) {
                List<AccessibilityNodeInfo> t = root.findAccessibilityNodeInfosByText(n);
                if (t != null) {
                    for (AccessibilityNodeInfo x : t) {
                        CharSequence d = x.getContentDescription();
                        if (d != null && d.toString().equalsIgnoreCase(n)) {
                            send = x;
                            break;
                        }
                    }
                }
                if (send != null) {
                    break;
                }
            }
        }
        if (send != null) {
            AccessibilityNodeInfo target = send;
            while (target != null && !target.isClickable()) {
                target = target.getParent();
            }
            if (target != null && target.performAction(AccessibilityNodeInfo.ACTION_CLICK)) {
                armUntil = 0;
                h.postDelayed(new Runnable() {
                    @Override
                    public void run() {
                        // संदेश जाने के बाद वापस FROST पर
                        Intent i = new Intent(FrostAccessibilityService.this, MainActivity.class);
                        i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_REORDER_TO_FRONT);
                        startActivity(i);
                    }
                }, 1500);
            }
        }
    }

    @Override
    public void onInterrupt() {
    }

    @Override
    public void onDestroy() {
        if (inst == this) {
            inst = null;
        }
        super.onDestroy();
    }
}
