package com.tushar.frost;

import android.accessibilityservice.AccessibilityService;
import android.content.ComponentName;
import android.content.ContentResolver;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.content.pm.ResolveInfo;
import android.database.Cursor;
import android.hardware.camera2.CameraManager;
import android.media.AudioManager;
import android.net.Uri;
import android.os.Build;
import android.provider.ContactsContract;
import android.provider.Settings;
import android.telephony.SmsManager;
import android.webkit.JavascriptInterface;

import java.net.URLEncoder;
import java.util.List;
import java.util.Locale;

/** पेज (JavaScript) से फ़ोन के काम: window.FrostNative.xxx() */
public class FrostBridge {

    private final Context ctx;

    FrostBridge(Context c) {
        ctx = c.getApplicationContext();
    }

    private void go(Intent i) {
        i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
        ctx.startActivity(i);
    }

    @JavascriptInterface
    public boolean call(String num) {
        try {
            go(new Intent(Intent.ACTION_CALL, Uri.parse("tel:+" + num.replaceAll("[^0-9]", ""))));
            return true;
        } catch (Exception e) {
            try {
                go(new Intent(Intent.ACTION_DIAL, Uri.parse("tel:+" + num.replaceAll("[^0-9]", ""))));
                return true;
            } catch (Exception e2) {
                return false;
            }
        }
    }

    @JavascriptInterface
    public boolean sms(String num, String text) {
        try {
            SmsManager m = Build.VERSION.SDK_INT >= 31 ? ctx.getSystemService(SmsManager.class) : SmsManager.getDefault();
            java.util.ArrayList<String> parts = m.divideMessage(text);
            m.sendMultipartTextMessage("+" + num.replaceAll("[^0-9]", ""), null, parts, null, null);
            return true;
        } catch (Exception e) {
            return false;
        }
    }

    @JavascriptInterface
    public boolean whatsapp(String num, String text) {
        try {
            String d = num.replaceAll("[^0-9]", "");
            Uri u = Uri.parse("https://wa.me/" + d + "?text=" + URLEncoder.encode(text, "UTF-8"));
            Intent i = new Intent(Intent.ACTION_VIEW, u);
            if (isInstalled("com.whatsapp")) {
                i.setPackage("com.whatsapp");
            } else if (isInstalled("com.whatsapp.w4b")) {
                i.setPackage("com.whatsapp.w4b");
            }
            FrostAccessibilityService.armSend();
            go(i);
            return true;
        } catch (Exception e) {
            return false;
        }
    }

    private boolean isInstalled(String pkg) {
        try {
            ctx.getPackageManager().getPackageInfo(pkg, 0);
            return true;
        } catch (Exception e) {
            return false;
        }
    }

    @JavascriptInterface
    public boolean openApp(String query) {
        try {
            String q = alias(query.toLowerCase(Locale.ROOT).trim());
            if (q.length() < 2) {
                return false;
            }
            PackageManager pm = ctx.getPackageManager();
            Intent main = new Intent(Intent.ACTION_MAIN);
            main.addCategory(Intent.CATEGORY_LAUNCHER);
            List<ResolveInfo> l = pm.queryIntentActivities(main, 0);
            ResolveInfo best = null;
            for (ResolveInfo r : l) {
                String label = String.valueOf(r.loadLabel(pm)).toLowerCase(Locale.ROOT);
                if (label.equals(q)) {
                    best = r;
                    break;
                }
                if (best == null && (label.contains(q) || q.contains(label))) {
                    best = r;
                }
            }
            if (best == null) {
                return false;
            }
            Intent i = new Intent(Intent.ACTION_MAIN);
            i.addCategory(Intent.CATEGORY_LAUNCHER);
            i.setComponent(new ComponentName(best.activityInfo.packageName, best.activityInfo.name));
            go(i);
            return true;
        } catch (Exception e) {
            return false;
        }
    }

    private String alias(String q) {
        String[][] a = new String[][]{
                {"व्हाट्सएप", "whatsapp"}, {"व्हाट्सऐप", "whatsapp"}, {"यूट्यूब", "youtube"}, {"यू ट्यूब", "youtube"},
                {"क्रोम", "chrome"}, {"कैमरा", "camera"}, {"गैलरी", "gallery"}, {"फोटो", "photos"}, {"फ़ोटो", "photos"},
                {"सेटिंग", "settings"}, {"सेटिंग्स", "settings"}, {"मैप्स", "maps"}, {"मैप", "maps"}, {"गूगल मैप", "maps"},
                {"इंस्टाग्राम", "instagram"}, {"जीमेल", "gmail"}, {"कैलकुलेटर", "calculator"}, {"घड़ी", "clock"},
                {"संपर्क", "contacts"}, {"कॉन्टैक्ट", "contacts"}, {"फोन", "phone"}, {"फ़ोन", "phone"}, {"संदेश", "messages"},
                {"स्पॉटिफाई", "spotify"}, {"टेलीग्राम", "telegram"}, {"फेसबुक", "facebook"}, {"पेटीएम", "paytm"}
        };
        for (String[] p : a) {
            if (q.equals(p[0]) || q.contains(p[0])) {
                return p[1];
            }
        }
        return q;
    }

    @JavascriptInterface
    public boolean torch(boolean on) {
        try {
            CameraManager cm = (CameraManager) ctx.getSystemService(Context.CAMERA_SERVICE);
            for (String id : cm.getCameraIdList()) {
                Boolean f = cm.getCameraCharacteristics(id).get(android.hardware.camera2.CameraCharacteristics.FLASH_INFO_AVAILABLE);
                if (f != null && f) {
                    cm.setTorchMode(id, on);
                    return true;
                }
            }
        } catch (Exception e) {
            // नहीं हो पाया
        }
        return false;
    }

    @JavascriptInterface
    public boolean lock() {
        return Build.VERSION.SDK_INT >= 28 && FrostAccessibilityService.globalAction(AccessibilityService.GLOBAL_ACTION_LOCK_SCREEN);
    }

    @JavascriptInterface
    public boolean home() {
        return FrostAccessibilityService.globalAction(AccessibilityService.GLOBAL_ACTION_HOME);
    }

    @JavascriptInterface
    public boolean back() {
        return FrostAccessibilityService.globalAction(AccessibilityService.GLOBAL_ACTION_BACK);
    }

    @JavascriptInterface
    public boolean recents() {
        return FrostAccessibilityService.globalAction(AccessibilityService.GLOBAL_ACTION_RECENTS);
    }

    @JavascriptInterface
    public boolean volume(String dir) {
        try {
            AudioManager am = (AudioManager) ctx.getSystemService(Context.AUDIO_SERVICE);
            int d = "up".equals(dir) ? AudioManager.ADJUST_RAISE : "down".equals(dir) ? AudioManager.ADJUST_LOWER : AudioManager.ADJUST_TOGGLE_MUTE;
            am.adjustStreamVolume(AudioManager.STREAM_MUSIC, d, AudioManager.FLAG_SHOW_UI);
            return true;
        } catch (Exception e) {
            return false;
        }
    }

    /** फ़ोन की संपर्क-सूची से नाम खोजकर पहला नंबर देता है, न मिले तो खाली। */
    @JavascriptInterface
    public String contactNumber(String name) {
        Cursor c = null;
        try {
            if (ctx.checkSelfPermission(android.Manifest.permission.READ_CONTACTS) != PackageManager.PERMISSION_GRANTED) {
                return "";
            }
            ContentResolver cr = ctx.getContentResolver();
            c = cr.query(ContactsContract.CommonDataKinds.Phone.CONTENT_URI,
                    new String[]{ContactsContract.CommonDataKinds.Phone.NUMBER},
                    ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME + " LIKE ?",
                    new String[]{"%" + name.trim() + "%"}, null);
            if (c != null && c.moveToFirst()) {
                return c.getString(0);
            }
        } catch (Exception e) {
            // कुछ नहीं
        } finally {
            if (c != null) {
                c.close();
            }
        }
        return "";
    }

    @JavascriptInterface
    public void listen(boolean on) {
        try {
            Intent i = new Intent(ctx, ListenService.class);
            if (on) {
                if (ctx.checkSelfPermission(android.Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
                    MainActivity.js("try{note('पहले माइक की अनुमति दीजिए, फिर «🎤 हमेशा सुनो» दोबारा दबाइए।')}catch(e){}");
                    return;
                }
                if (Build.VERSION.SDK_INT >= 26) {
                    ctx.startForegroundService(i);
                } else {
                    ctx.startService(i);
                }
            } else {
                if (!ListenService.running) {
                    return;
                }
                i.setAction("STOP");
                ctx.startService(i);
            }
        } catch (Throwable e) {
            MainActivity.js("try{note('सुनना शुरू नहीं हो पाया।')}catch(e){}");
        }
    }

    @JavascriptInterface
    public void setMuted(boolean m) {
        ListenService.muted = m;
    }

    @JavascriptInterface
    public boolean a11yEnabled() {
        return FrostAccessibilityService.inst != null;
    }

    @JavascriptInterface
    public void openA11ySettings() {
        go(new Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS));
    }

    @JavascriptInterface
    public void openAppSettings() {
        Intent i = new Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:" + ctx.getPackageName()));
        go(i);
    }
}
